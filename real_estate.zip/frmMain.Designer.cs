﻿namespace Khan_Stockl_Assign3
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMaxPrice = new System.Windows.Forms.Label();
            this.lblMinPrice = new System.Windows.Forms.Label();
            this.tbMaxPrice = new System.Windows.Forms.TrackBar();
            this.tbMinPrice = new System.Windows.Forms.TrackBar();
            this.chkSchool = new System.Windows.Forms.CheckBox();
            this.chkBusiness = new System.Windows.Forms.CheckBox();
            this.chkResidential = new System.Windows.Forms.CheckBox();
            this.lblSchoolDistance = new System.Windows.Forms.Label();
            this.lblSchool = new System.Windows.Forms.Label();
            this.boxQueryResult = new System.Windows.Forms.GroupBox();
            this.txtOutput = new System.Windows.Forms.RichTextBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.tcQuery = new System.Windows.Forms.TabControl();
            this.tabByPriceRange = new System.Windows.Forms.TabPage();
            this.tabByRangeSchool = new System.Windows.Forms.TabPage();
            this.nudSchoolDistance = new System.Windows.Forms.NumericUpDown();
            this.cmbSchools = new System.Windows.Forms.ComboBox();
            this.tabByHiringBusiness = new System.Windows.Forms.TabPage();
            this.nudBusinessDistance = new System.Windows.Forms.NumericUpDown();
            this.cmbResidences = new System.Windows.Forms.ComboBox();
            this.lblForSaleDistance = new System.Windows.Forms.Label();
            this.lblForSaleResidences = new System.Windows.Forms.Label();
            this.tabResidenceParm = new System.Windows.Forms.TabPage();
            this.nudSqFt = new System.Windows.Forms.NumericUpDown();
            this.nudBath = new System.Windows.Forms.NumericUpDown();
            this.nudBed = new System.Windows.Forms.NumericUpDown();
            this.chkGarage = new System.Windows.Forms.CheckBox();
            this.lblSqFt = new System.Windows.Forms.Label();
            this.chkHouse = new System.Windows.Forms.CheckBox();
            this.chkApartment = new System.Windows.Forms.CheckBox();
            this.lblBath = new System.Windows.Forms.Label();
            this.lblBed = new System.Windows.Forms.Label();
            this.tabOther = new System.Windows.Forms.TabPage();
            this.optPropertiesOwnedOutOfTowners = new System.Windows.Forms.RadioButton();
            this.boxQueryOption = new System.Windows.Forms.GroupBox();
            this.lblAuthor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tbMaxPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbMinPrice)).BeginInit();
            this.boxQueryResult.SuspendLayout();
            this.tcQuery.SuspendLayout();
            this.tabByPriceRange.SuspendLayout();
            this.tabByRangeSchool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSchoolDistance)).BeginInit();
            this.tabByHiringBusiness.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudBusinessDistance)).BeginInit();
            this.tabResidenceParm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSqFt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBed)).BeginInit();
            this.tabOther.SuspendLayout();
            this.boxQueryOption.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMaxPrice
            // 
            this.lblMaxPrice.AutoSize = true;
            this.lblMaxPrice.Location = new System.Drawing.Point(175, 80);
            this.lblMaxPrice.Name = "lblMaxPrice";
            this.lblMaxPrice.Size = new System.Drawing.Size(161, 14);
            this.lblMaxPrice.TabIndex = 6;
            this.lblMaxPrice.Text = "Max Price: $250,000.00";
            // 
            // lblMinPrice
            // 
            this.lblMinPrice.AutoSize = true;
            this.lblMinPrice.Location = new System.Drawing.Point(175, 21);
            this.lblMinPrice.Name = "lblMinPrice";
            this.lblMinPrice.Size = new System.Drawing.Size(119, 14);
            this.lblMinPrice.TabIndex = 5;
            this.lblMinPrice.Text = "Min Price: $0.00";
            // 
            // tbMaxPrice
            // 
            this.tbMaxPrice.Location = new System.Drawing.Point(178, 97);
            this.tbMaxPrice.Maximum = 350000;
            this.tbMaxPrice.Name = "tbMaxPrice";
            this.tbMaxPrice.Size = new System.Drawing.Size(202, 45);
            this.tbMaxPrice.TabIndex = 4;
            this.tbMaxPrice.Value = 250000;
            this.tbMaxPrice.ValueChanged += new System.EventHandler(this.tbMaxPrice_ValueChanged);
            // 
            // tbMinPrice
            // 
            this.tbMinPrice.Location = new System.Drawing.Point(178, 38);
            this.tbMinPrice.Maximum = 350000;
            this.tbMinPrice.Name = "tbMinPrice";
            this.tbMinPrice.Size = new System.Drawing.Size(202, 45);
            this.tbMinPrice.TabIndex = 3;
            this.tbMinPrice.ValueChanged += new System.EventHandler(this.tbMinPrice_ValueChanged);
            // 
            // chkSchool
            // 
            this.chkSchool.AutoSize = true;
            this.chkSchool.Location = new System.Drawing.Point(22, 86);
            this.chkSchool.Name = "chkSchool";
            this.chkSchool.Size = new System.Drawing.Size(68, 18);
            this.chkSchool.TabIndex = 2;
            this.chkSchool.Text = "School";
            this.chkSchool.UseVisualStyleBackColor = true;
            // 
            // chkBusiness
            // 
            this.chkBusiness.AutoSize = true;
            this.chkBusiness.Location = new System.Drawing.Point(22, 62);
            this.chkBusiness.Name = "chkBusiness";
            this.chkBusiness.Size = new System.Drawing.Size(82, 18);
            this.chkBusiness.TabIndex = 1;
            this.chkBusiness.Text = "Business";
            this.chkBusiness.UseVisualStyleBackColor = true;
            // 
            // chkResidential
            // 
            this.chkResidential.AutoSize = true;
            this.chkResidential.Location = new System.Drawing.Point(22, 38);
            this.chkResidential.Name = "chkResidential";
            this.chkResidential.Size = new System.Drawing.Size(103, 18);
            this.chkResidential.TabIndex = 0;
            this.chkResidential.Text = "Residential";
            this.chkResidential.UseVisualStyleBackColor = true;
            // 
            // lblSchoolDistance
            // 
            this.lblSchoolDistance.AutoSize = true;
            this.lblSchoolDistance.Location = new System.Drawing.Point(304, 53);
            this.lblSchoolDistance.Name = "lblSchoolDistance";
            this.lblSchoolDistance.Size = new System.Drawing.Size(63, 14);
            this.lblSchoolDistance.TabIndex = 1;
            this.lblSchoolDistance.Text = "Distance";
            // 
            // lblSchool
            // 
            this.lblSchool.AutoSize = true;
            this.lblSchool.Location = new System.Drawing.Point(35, 53);
            this.lblSchool.Name = "lblSchool";
            this.lblSchool.Size = new System.Drawing.Size(49, 14);
            this.lblSchool.TabIndex = 0;
            this.lblSchool.Text = "School";
            // 
            // boxQueryResult
            // 
            this.boxQueryResult.Controls.Add(this.txtOutput);
            this.boxQueryResult.Location = new System.Drawing.Point(534, 12);
            this.boxQueryResult.Name = "boxQueryResult";
            this.boxQueryResult.Size = new System.Drawing.Size(482, 452);
            this.boxQueryResult.TabIndex = 1;
            this.boxQueryResult.TabStop = false;
            this.boxQueryResult.Text = "Query Result";
            // 
            // txtOutput
            // 
            this.txtOutput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOutput.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtOutput.Location = new System.Drawing.Point(6, 19);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(470, 427);
            this.txtOutput.TabIndex = 0;
            this.txtOutput.Text = "";
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(380, 235);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(126, 23);
            this.btnQuery.TabIndex = 2;
            this.btnQuery.Text = "Query";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // tcQuery
            // 
            this.tcQuery.Controls.Add(this.tabByPriceRange);
            this.tcQuery.Controls.Add(this.tabByRangeSchool);
            this.tcQuery.Controls.Add(this.tabByHiringBusiness);
            this.tcQuery.Controls.Add(this.tabResidenceParm);
            this.tcQuery.Controls.Add(this.tabOther);
            this.tcQuery.Location = new System.Drawing.Point(6, 19);
            this.tcQuery.Multiline = true;
            this.tcQuery.Name = "tcQuery";
            this.tcQuery.SelectedIndex = 0;
            this.tcQuery.Size = new System.Drawing.Size(504, 210);
            this.tcQuery.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tcQuery.TabIndex = 3;
            // 
            // tabByPriceRange
            // 
            this.tabByPriceRange.Controls.Add(this.lblMaxPrice);
            this.tabByPriceRange.Controls.Add(this.chkResidential);
            this.tabByPriceRange.Controls.Add(this.lblMinPrice);
            this.tabByPriceRange.Controls.Add(this.chkBusiness);
            this.tabByPriceRange.Controls.Add(this.tbMaxPrice);
            this.tabByPriceRange.Controls.Add(this.chkSchool);
            this.tabByPriceRange.Controls.Add(this.tbMinPrice);
            this.tabByPriceRange.Location = new System.Drawing.Point(4, 42);
            this.tabByPriceRange.Name = "tabByPriceRange";
            this.tabByPriceRange.Padding = new System.Windows.Forms.Padding(3);
            this.tabByPriceRange.Size = new System.Drawing.Size(496, 164);
            this.tabByPriceRange.TabIndex = 0;
            this.tabByPriceRange.Text = "Residence By Price";
            this.tabByPriceRange.UseVisualStyleBackColor = true;
            // 
            // tabByRangeSchool
            // 
            this.tabByRangeSchool.Controls.Add(this.nudSchoolDistance);
            this.tabByRangeSchool.Controls.Add(this.cmbSchools);
            this.tabByRangeSchool.Controls.Add(this.lblSchoolDistance);
            this.tabByRangeSchool.Controls.Add(this.lblSchool);
            this.tabByRangeSchool.Location = new System.Drawing.Point(4, 42);
            this.tabByRangeSchool.Name = "tabByRangeSchool";
            this.tabByRangeSchool.Padding = new System.Windows.Forms.Padding(3);
            this.tabByRangeSchool.Size = new System.Drawing.Size(496, 164);
            this.tabByRangeSchool.TabIndex = 1;
            this.tabByRangeSchool.Text = "Residence Distance To School";
            this.tabByRangeSchool.UseVisualStyleBackColor = true;
            // 
            // nudSchoolDistance
            // 
            this.nudSchoolDistance.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nudSchoolDistance.Location = new System.Drawing.Point(307, 70);
            this.nudSchoolDistance.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nudSchoolDistance.Name = "nudSchoolDistance";
            this.nudSchoolDistance.Size = new System.Drawing.Size(120, 20);
            this.nudSchoolDistance.TabIndex = 3;
            // 
            // cmbSchools
            // 
            this.cmbSchools.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSchools.FormattingEnabled = true;
            this.cmbSchools.Location = new System.Drawing.Point(38, 70);
            this.cmbSchools.Name = "cmbSchools";
            this.cmbSchools.Size = new System.Drawing.Size(230, 22);
            this.cmbSchools.TabIndex = 2;
            // 
            // tabByHiringBusiness
            // 
            this.tabByHiringBusiness.Controls.Add(this.nudBusinessDistance);
            this.tabByHiringBusiness.Controls.Add(this.cmbResidences);
            this.tabByHiringBusiness.Controls.Add(this.lblForSaleDistance);
            this.tabByHiringBusiness.Controls.Add(this.lblForSaleResidences);
            this.tabByHiringBusiness.Location = new System.Drawing.Point(4, 42);
            this.tabByHiringBusiness.Name = "tabByHiringBusiness";
            this.tabByHiringBusiness.Size = new System.Drawing.Size(496, 164);
            this.tabByHiringBusiness.TabIndex = 2;
            this.tabByHiringBusiness.Text = "Business Within Range of Residence";
            this.tabByHiringBusiness.UseVisualStyleBackColor = true;
            // 
            // nudBusinessDistance
            // 
            this.nudBusinessDistance.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nudBusinessDistance.Location = new System.Drawing.Point(307, 70);
            this.nudBusinessDistance.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nudBusinessDistance.Name = "nudBusinessDistance";
            this.nudBusinessDistance.Size = new System.Drawing.Size(120, 20);
            this.nudBusinessDistance.TabIndex = 7;
            // 
            // cmbResidences
            // 
            this.cmbResidences.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbResidences.FormattingEnabled = true;
            this.cmbResidences.Location = new System.Drawing.Point(38, 70);
            this.cmbResidences.Name = "cmbResidences";
            this.cmbResidences.Size = new System.Drawing.Size(230, 22);
            this.cmbResidences.TabIndex = 6;
            // 
            // lblForSaleDistance
            // 
            this.lblForSaleDistance.AutoSize = true;
            this.lblForSaleDistance.Location = new System.Drawing.Point(304, 53);
            this.lblForSaleDistance.Name = "lblForSaleDistance";
            this.lblForSaleDistance.Size = new System.Drawing.Size(63, 14);
            this.lblForSaleDistance.TabIndex = 5;
            this.lblForSaleDistance.Text = "Distance";
            // 
            // lblForSaleResidences
            // 
            this.lblForSaleResidences.AutoSize = true;
            this.lblForSaleResidences.Location = new System.Drawing.Point(35, 53);
            this.lblForSaleResidences.Name = "lblForSaleResidences";
            this.lblForSaleResidences.Size = new System.Drawing.Size(140, 14);
            this.lblForSaleResidences.TabIndex = 4;
            this.lblForSaleResidences.Text = "For-Sale Residences";
            // 
            // tabResidenceParm
            // 
            this.tabResidenceParm.Controls.Add(this.nudSqFt);
            this.tabResidenceParm.Controls.Add(this.nudBath);
            this.tabResidenceParm.Controls.Add(this.nudBed);
            this.tabResidenceParm.Controls.Add(this.chkGarage);
            this.tabResidenceParm.Controls.Add(this.lblSqFt);
            this.tabResidenceParm.Controls.Add(this.chkHouse);
            this.tabResidenceParm.Controls.Add(this.chkApartment);
            this.tabResidenceParm.Controls.Add(this.lblBath);
            this.tabResidenceParm.Controls.Add(this.lblBed);
            this.tabResidenceParm.Location = new System.Drawing.Point(4, 42);
            this.tabResidenceParm.Name = "tabResidenceParm";
            this.tabResidenceParm.Size = new System.Drawing.Size(496, 164);
            this.tabResidenceParm.TabIndex = 3;
            this.tabResidenceParm.Text = "Residence Parameters";
            this.tabResidenceParm.UseVisualStyleBackColor = true;
            // 
            // nudSqFt
            // 
            this.nudSqFt.Increment = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nudSqFt.Location = new System.Drawing.Point(217, 63);
            this.nudSqFt.Maximum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.nudSqFt.Minimum = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            this.nudSqFt.Name = "nudSqFt";
            this.nudSqFt.Size = new System.Drawing.Size(74, 20);
            this.nudSqFt.TabIndex = 8;
            this.nudSqFt.Value = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            // 
            // nudBath
            // 
            this.nudBath.Location = new System.Drawing.Point(168, 63);
            this.nudBath.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.nudBath.Name = "nudBath";
            this.nudBath.Size = new System.Drawing.Size(36, 20);
            this.nudBath.TabIndex = 7;
            // 
            // nudBed
            // 
            this.nudBed.Location = new System.Drawing.Point(120, 63);
            this.nudBed.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.nudBed.Name = "nudBed";
            this.nudBed.Size = new System.Drawing.Size(36, 20);
            this.nudBed.TabIndex = 6;
            // 
            // chkGarage
            // 
            this.chkGarage.AutoSize = true;
            this.chkGarage.Location = new System.Drawing.Point(297, 65);
            this.chkGarage.Name = "chkGarage";
            this.chkGarage.Size = new System.Drawing.Size(68, 18);
            this.chkGarage.TabIndex = 5;
            this.chkGarage.Text = "Garage";
            this.chkGarage.UseVisualStyleBackColor = true;
            // 
            // lblSqFt
            // 
            this.lblSqFt.AutoSize = true;
            this.lblSqFt.Location = new System.Drawing.Point(214, 41);
            this.lblSqFt.Name = "lblSqFt";
            this.lblSqFt.Size = new System.Drawing.Size(77, 14);
            this.lblSqFt.TabIndex = 4;
            this.lblSqFt.Text = "Min Sq.Ft.";
            // 
            // chkHouse
            // 
            this.chkHouse.AutoSize = true;
            this.chkHouse.Location = new System.Drawing.Point(15, 40);
            this.chkHouse.Name = "chkHouse";
            this.chkHouse.Size = new System.Drawing.Size(61, 18);
            this.chkHouse.TabIndex = 0;
            this.chkHouse.Text = "House";
            this.chkHouse.UseVisualStyleBackColor = true;
            // 
            // chkApartment
            // 
            this.chkApartment.AutoSize = true;
            this.chkApartment.Location = new System.Drawing.Point(15, 65);
            this.chkApartment.Name = "chkApartment";
            this.chkApartment.Size = new System.Drawing.Size(89, 18);
            this.chkApartment.TabIndex = 1;
            this.chkApartment.Text = "Apartment";
            this.chkApartment.UseVisualStyleBackColor = true;
            // 
            // lblBath
            // 
            this.lblBath.AutoSize = true;
            this.lblBath.Location = new System.Drawing.Point(165, 41);
            this.lblBath.Name = "lblBath";
            this.lblBath.Size = new System.Drawing.Size(35, 14);
            this.lblBath.TabIndex = 3;
            this.lblBath.Text = "Bath";
            // 
            // lblBed
            // 
            this.lblBed.AutoSize = true;
            this.lblBed.Location = new System.Drawing.Point(117, 41);
            this.lblBed.Name = "lblBed";
            this.lblBed.Size = new System.Drawing.Size(28, 14);
            this.lblBed.TabIndex = 2;
            this.lblBed.Text = "Bed";
            // 
            // tabOther
            // 
            this.tabOther.Controls.Add(this.optPropertiesOwnedOutOfTowners);
            this.tabOther.Location = new System.Drawing.Point(4, 42);
            this.tabOther.Name = "tabOther";
            this.tabOther.Size = new System.Drawing.Size(496, 164);
            this.tabOther.TabIndex = 4;
            this.tabOther.Text = "Other Query";
            this.tabOther.UseVisualStyleBackColor = true;
            // 
            // optPropertiesOwnedOutOfTowners
            // 
            this.optPropertiesOwnedOutOfTowners.AutoSize = true;
            this.optPropertiesOwnedOutOfTowners.Location = new System.Drawing.Point(22, 31);
            this.optPropertiesOwnedOutOfTowners.Name = "optPropertiesOwnedOutOfTowners";
            this.optPropertiesOwnedOutOfTowners.Size = new System.Drawing.Size(263, 18);
            this.optPropertiesOwnedOutOfTowners.TabIndex = 1;
            this.optPropertiesOwnedOutOfTowners.TabStop = true;
            this.optPropertiesOwnedOutOfTowners.Text = "Properties Owned by Out-Of-Towners";
            this.optPropertiesOwnedOutOfTowners.UseVisualStyleBackColor = true;

            // 
            // boxQueryOption
            // 
            this.boxQueryOption.Controls.Add(this.tcQuery);
            this.boxQueryOption.Controls.Add(this.btnQuery);
            this.boxQueryOption.Location = new System.Drawing.Point(12, 12);
            this.boxQueryOption.Name = "boxQueryOption";
            this.boxQueryOption.Size = new System.Drawing.Size(516, 267);
            this.boxQueryOption.TabIndex = 4;
            this.boxQueryOption.TabStop = false;
            this.boxQueryOption.Text = "Query By...";
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuthor.Location = new System.Drawing.Point(9, 451);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(98, 15);
            this.lblAuthor.TabIndex = 5;
            this.lblAuthor.Text = "Khan, Stockl ";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 475);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.boxQueryOption);
            this.Controls.Add(this.boxQueryResult);
            this.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.Text = "Real Estate Querying System";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbMaxPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbMinPrice)).EndInit();
            this.boxQueryResult.ResumeLayout(false);
            this.tcQuery.ResumeLayout(false);
            this.tabByPriceRange.ResumeLayout(false);
            this.tabByPriceRange.PerformLayout();
            this.tabByRangeSchool.ResumeLayout(false);
            this.tabByRangeSchool.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSchoolDistance)).EndInit();
            this.tabByHiringBusiness.ResumeLayout(false);
            this.tabByHiringBusiness.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudBusinessDistance)).EndInit();
            this.tabResidenceParm.ResumeLayout(false);
            this.tabResidenceParm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSqFt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBed)).EndInit();
            this.tabOther.ResumeLayout(false);
            this.tabOther.PerformLayout();
            this.boxQueryOption.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblMaxPrice;
        private System.Windows.Forms.Label lblMinPrice;
        private System.Windows.Forms.TrackBar tbMaxPrice;
        private System.Windows.Forms.TrackBar tbMinPrice;
        private System.Windows.Forms.CheckBox chkSchool;
        private System.Windows.Forms.CheckBox chkBusiness;
        private System.Windows.Forms.CheckBox chkResidential;
        private System.Windows.Forms.GroupBox boxQueryResult;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Label lblSchoolDistance;
        private System.Windows.Forms.Label lblSchool;
        private System.Windows.Forms.TabControl tcQuery;
        private System.Windows.Forms.TabPage tabByPriceRange;
        private System.Windows.Forms.TabPage tabByRangeSchool;
        private System.Windows.Forms.NumericUpDown nudSchoolDistance;
        private System.Windows.Forms.ComboBox cmbSchools;
        private System.Windows.Forms.TabPage tabByHiringBusiness;
        private System.Windows.Forms.TabPage tabResidenceParm;
        private System.Windows.Forms.GroupBox boxQueryOption;
        private System.Windows.Forms.NumericUpDown nudBusinessDistance;
        private System.Windows.Forms.ComboBox cmbResidences;
        private System.Windows.Forms.Label lblForSaleDistance;
        private System.Windows.Forms.Label lblForSaleResidences;
        private System.Windows.Forms.TabPage tabOther;
        private System.Windows.Forms.NumericUpDown nudBed;
        private System.Windows.Forms.CheckBox chkGarage;
        private System.Windows.Forms.Label lblSqFt;
        private System.Windows.Forms.Label lblBath;
        private System.Windows.Forms.Label lblBed;
        private System.Windows.Forms.CheckBox chkApartment;
        private System.Windows.Forms.CheckBox chkHouse;
        private System.Windows.Forms.NumericUpDown nudSqFt;
        private System.Windows.Forms.NumericUpDown nudBath;
        private System.Windows.Forms.RadioButton optPropertiesOwnedOutOfTowners;
        private System.Windows.Forms.RichTextBox txtOutput;
        private System.Windows.Forms.Label lblAuthor;
    }
}

