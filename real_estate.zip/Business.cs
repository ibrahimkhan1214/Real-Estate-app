﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Khan_Stockl_Assign3
{
    class Business : Property
    {
        public enum BusinessType { Grocery, Bank, Repair, FastFood, DepartmentStore };
        
        /* Private Variables */
        string name;
        readonly BusinessType type;
        readonly string yearEstablished;
        uint activeRecruitment;


        public string Name { get => name; set => name = value; }
        public string YearEstablished => yearEstablished;
        public uint ActiveRecruitment { get => activeRecruitment; set => activeRecruitment = value; }



        /**
        * @brief Creates a Business object with default values
        **/
        public Business() : base()
        {
            name = "";
            type = BusinessType.Bank;
            yearEstablished = "";
            activeRecruitment = 0;
        }


        /**
        * @brief Creates a Business object with specified values
        * 
        * @param args A string array of arguments ordered:
        *                  0: id
        *                  1: ownerId
        *                  2: x
        *                  3: y
        *                  4: streetAddr
        *                  5: city
        *                  6: state
        *                  7: zip
        *                  8: forSale
        *                  9: businessName
        *                 10: BusinessType (enum)
        *                 11: yearEsablished 
        *                 12: activeRecruitment
        * @note arg index 0-8 is used in base class construction
        **/
        public string getbusinesstype()
        {
            string TYPE;

            switch (type)
            {
                case BusinessType.Bank:
                    TYPE = "bank";
                    break;
                case BusinessType.DepartmentStore:
                    TYPE = "departmental store";
                    break;
                case BusinessType.FastFood:
                    TYPE = "fast food";
                    break;
                case BusinessType.Grocery:
                    TYPE = "Grocery store";
                    break;
                case BusinessType.Repair:
                    TYPE = "repair shop";
                    break;
                default:
                    TYPE = "No info available";
                    break;
            }
            return TYPE;
        }
        public Business(string[] args) : base(args)
        {
            this.name = args[9];

            int tryParseInt = 0;
            
            if (int.TryParse(args[10], out tryParseInt) == false)
            {
                throw new ArgumentException("Error parsing '" + args[10] + "' into uint Business.BusinessType (Integer)");
            }

            switch ( tryParseInt )
            {
                case 0:
                    this.type = BusinessType.Grocery;
                    break;
                case 1:
                    this.type = BusinessType.Bank;
                    break;
                case 2:
                    this.type = BusinessType.Repair;
                    break;
                case 3:
                    this.type = BusinessType.FastFood;
                    break;
                case 4:
                    this.type = BusinessType.DepartmentStore;
                    break;
                default:
                    throw new ArgumentException("Error parsing '" + args[10] + "' into uint Business.BusinessType (Integer)");
            }

            this.yearEstablished = args[11];

            if (uint.TryParse(args[12], out this.activeRecruitment) == false)
            {
                throw new ArgumentException("Error parsing '" + args[12] + "' into Business.activeRecuritment");
            }

        }
    }
}
