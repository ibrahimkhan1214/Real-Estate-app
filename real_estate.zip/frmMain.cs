﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Khan_Stockl_Assign3
{
    public partial class frmMain : Form
    {

        // Communities
        private Community DeKalb = new Community("../../data/DeKalb/persons.txt", "../../data/DeKalb/houses.txt", "../../data/DeKalb/apartments.txt", "../../data/DeKalb/businesses.txt", "../../data/DeKalb/schools.txt", 1, "DeKalb", "Illinois", "60115", 0);
        private Community Sycamore = new Community("../../data/Sycamore/persons.txt", "../../data/Sycamore/houses.txt", "../../data/Sycamore/apartments.txt", "../../data/Sycamore/businesses.txt", "../../data/Sycamore/schools.txt", 2, "Sycamore", "Illinois", "60178", 10100);


        public frmMain()
        {
            InitializeComponent();
        }

        /**
         * @brief Runs on form load, initalizes combo boxes
         **/
        private void frmMain_Load(object sender, EventArgs e)
        {
            // Load School combobox
            cmbSchools.Items.Add("DeKalb:");
            cmbSchools.Items.Add("------------");
            foreach (Property p in DeKalb.Properties)
            {
                if (p is School)
                {
                    cmbSchools.Items.Add(((School)p).Name);
                }
            }
            cmbSchools.Items.Add("");
            cmbSchools.Items.Add("Sycamore:");
            cmbSchools.Items.Add("------------");
            foreach (Property p in Sycamore.Properties)
            {
                if (p is School)
                {
                    cmbSchools.Items.Add(((School)p).Name);
                }
            }


            // Load Residence Combobox
            cmbResidences.Items.Add("DeKalb:");
            cmbResidences.Items.Add("------------");
            foreach (Property p in DeKalb.Properties)
            {
                if (p is House && p.ForSale)
                {
                    cmbResidences.Items.Add(p.StreetAddr);
                }
            }
            cmbResidences.Items.Add("");
            foreach (Property p in DeKalb.Properties)
            {
                if (p is Apartment && p.ForSale)
                {
                    cmbResidences.Items.Add(p.StreetAddr + " # " + ((Apartment)p).Unit);
                }
            }
            cmbResidences.Items.Add("");
            cmbResidences.Items.Add("Sycamore:");
            cmbResidences.Items.Add("------------");
            foreach (Property p in Sycamore.Properties)
            {
                if (p is House && p.ForSale)
                {
                    cmbResidences.Items.Add(p.StreetAddr);
                }
            }
            cmbResidences.Items.Add("");
            foreach (Property p in Sycamore.Properties)
            {
                if (p is Apartment && p.ForSale)
                {
                    cmbResidences.Items.Add(p.StreetAddr + " # " + ((Apartment)p).Unit);
                }
            }
        }

        /**
         * @brief Handles price range value changed event
         **/
        private void tbMinPrice_ValueChanged(object sender, EventArgs e)
        {
            lblMinPrice.Text = "Min Price: " + String.Format("{0:C2}", tbMinPrice.Value);

            if (tbMaxPrice.Value <= tbMinPrice.Value)
            {
                tbMaxPrice.Value = tbMinPrice.Value;
            }
        }

        /**
         * @brief Handles price range value changed event
         **/
        private void tbMaxPrice_ValueChanged(object sender, EventArgs e)
        {
            lblMaxPrice.Text = "Max Price: " + String.Format("{0:C2}", tbMaxPrice.Value);

            if (tbMaxPrice.Value <= tbMinPrice.Value)
            {
                tbMinPrice.Value = tbMaxPrice.Value;
            }
        }

        /**
         * @brief Dispatches query button event to correct query
         *
         * Since we're using only 1 query button, we will determine what query to perform
         * by checking what tab is selected.
         **/
        private void btnQuery_Click(object sender, EventArgs e)
        {
            // Clear previous results
            txtOutput.Text = "";

            // Determine what query we're doing
            if (tcQuery.SelectedTab == tabByPriceRange)
            {
                // Query button is for "For Sale Properties Within Price Range"
                queryByPriceRange();
            }
            else if (tcQuery.SelectedTab == tabByRangeSchool)
            {
                // Query button is for "For Sale Residences Within Range of a School"
                queryByRangeOfSchool();
            }
            else if (tcQuery.SelectedTab == tabByHiringBusiness)
            {
                // Query button is for "Hiring Businesses Within Rnage of For Sale Residence"
                queryByHiringBusinessRange();
            }
            else if (tcQuery.SelectedTab == tabResidenceParm)
            {
                // Query button is for "Specific Residence Parameters"
                queryByResidenceParameters();
            }
            else if(tcQuery.SelectedTab == tabOther)
            {
                // Quey button is for "To Other"
                queryByOther();
            }

        }


        /////////////////////////////// TODO ////////////////////////////////////
        // Implement queries below
        //////////////////////////////////////////////////////////////////////////


        private void queryByPriceRange()
        {
            if (!chkResidential.Checked && !chkBusiness.Checked && !chkSchool.Checked) return;

            var ByPriceRangeQuery =
                from prop in DeKalb.Properties.Union(Sycamore.Properties)
                where prop.ForSale == true
                where prop.SalePrice <= tbMaxPrice.Value && prop.SalePrice >= tbMinPrice.Value
                select prop;

            if (!chkResidential.Checked)
                ByPriceRangeQuery = ByPriceRangeQuery.Where(i => i is Residential == false);

            if (!chkBusiness.Checked)
                ByPriceRangeQuery = ByPriceRangeQuery.Where(i => i is Business == false);

            if (!chkSchool.Checked)
                ByPriceRangeQuery = ByPriceRangeQuery.Where(i => i is School == false);



            foreach (var v in ByPriceRangeQuery)
            {
                txtOutput.AppendText(v.StreetAddr + "\n");
            }




        }
        int distanceCalc(int x1, int x2, int y1, int y2)
        {
            int result = 0;
            result = Convert.ToInt32(Math.Sqrt((Math.Pow((x2 - x2), 2)) + (Math.Pow((y2 - y1), 2))));
            return result;
        }

        private void queryByRangeOfSchool()
        {
            if (cmbSchools.SelectedItem == null)
            {
                txtOutput.AppendText("Please select a school from drop down menu");
                return;
            }

            //  uint ii = 0;
            //  int x = 0;
            uint X = 0;
            uint Y = 0;
            foreach (Property v in DeKalb.Properties.Union(Sycamore.Properties))
            {
                if (v is School)
                {
                    if (cmbSchools.SelectedItem.ToString() == ((School)v).Name)
                    {

                        X = v.X;
                        Y = v.Y;

                    }

                }

            }




            var BydistanceQuery =
            from prop in DeKalb.Properties.Union(Sycamore.Properties)
            where prop.ForSale == true
            where prop.distanceCalc(X, prop.X, Y, prop.Y) <= Convert.ToInt32(nudSchoolDistance.Value)
            select prop;


            txtOutput.AppendText("Residences for sale within " + Convert.ToInt32(nudSchoolDistance.Value) + " units of distance from \n\t\t" + cmbSchools.SelectedItem.ToString() + "\n" + "----------------------------------------------------------------\n");
            foreach (var v in BydistanceQuery)
            {

                txtOutput.AppendText(v.FullAddress() + " " + Convert.ToInt32(v.distanceCalc(X, v.X, Y, v.Y)) + " Units away Owner: ");
                foreach (Person p in DeKalb.Residents.Union(Sycamore.Residents))
                {
                    if (p.Id == v.OwnerId)
                    {
                        txtOutput.AppendText(p.FullName + " | ");
                    }
                }
                if (v is Residential)
                {
                    txtOutput.AppendText(Convert.ToUInt32(((Residential)v).Bedrooms) + " beds, " + Convert.ToUInt32(((Residential)v).Baths) + " baths, " + Convert.ToUInt32(((Residential)v).Sqft) + " sq.ft.\n");

                }
                else if (v is Business)
                {
                    txtOutput.AppendText(((Business)v).Name);
                    txtOutput.AppendText(" is a business. ");
                }
                else if (v is Apartment)
                {
                    txtOutput.AppendText(" Apt.# " + ((Apartment)v).Unit + "\n");
                }
                if (v is House)
                {


                    switch (((House)v).AttachedGarage)
                    {
                        // No garage
                        case null:
                            txtOutput.AppendText(" with no garage : ");
                            break;

                        // Garage and attached
                        case true:
                            txtOutput.AppendText(" with an attached garage : ");
                            break;

                        // Garage and not attached
                        case false:
                            txtOutput.AppendText(" with a detached garage : ");
                            break;
                    }
                    txtOutput.AppendText(" " + ((House)v).Floors + " Floors.   ");
                }
                txtOutput.AppendText("$" + v.SalePrice + "\n\n");


            }
        }

        private void queryByHiringBusinessRange()
        {
            uint X = 0;
            uint Y = 0;
            foreach (Property v in DeKalb.Properties.Union(Sycamore.Properties))
            {
                if (v is Business)
                {
                    if (((Business)v).ActiveRecruitment > 0)
                    {

                        X = v.X;
                        Y = v.Y;

                    }


                }

            }
            /*
                        var BydistanceQuery =
                        from Business in DeKalb.Properties.Union(Sycamore.Properties)
                        where Business.ForSale == true
                        where Business.distanceCalc(Business.X, X, Business.Y, Y) <= Convert.ToInt32(nudBusinessDistance.Value)
                        select Business;
                       */

            var BydistanceQuery =
            from prop in DeKalb.Properties.Union(Sycamore.Properties)
            where prop.ForSale == true
            where prop is Business
            where prop.distanceCalc(X, prop.X, Y, prop.Y) <= Convert.ToInt32(nudBusinessDistance.Value)
            select prop;


            txtOutput.AppendText("Hiring Business within " + Convert.ToInt32(nudBusinessDistance.Value) + " units of distance from \n\t\t" + cmbResidences.SelectedItem.ToString() + "\n" + "----------------------------------------------------------------\n");
            foreach (var v in BydistanceQuery)
            {
                txtOutput.AppendText("\n" + v.FullAddress() + " Owner: ");
                foreach (Person p in DeKalb.Residents.Union(Sycamore.Residents))
                {
                    if (p.Id == v.OwnerId)
                    {
                        txtOutput.AppendText(p.FullName + " | ");
                    }
                }
                if (v is Business)
                {

                    txtOutput.AppendText(Convert.ToInt32(v.distanceCalc(X, v.X, Y, v.Y)) + " units away, with " + ((Business)v).ActiveRecruitment + " open positions " + ((Business)v).Name + ", " + ((Business)v).getbusinesstype() + ", " + "established in " + ((Business)v).YearEstablished + "\n\n");
                }
            }
        }

        private void queryByResidenceParameters()
        {
           

        }

        private void cmbSchools_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void queryByOther()
        {
            if (optPropertiesOwnedOutOfTowners.Checked)
            {
                var outQuery =
                from prop in DeKalb.Properties

                select prop;
                foreach (var v in outQuery)
                {

                    foreach (Person p in DeKalb.Residents)
                    {

                        if (Sycamore.outtowners(p) == true && p.Id == v.OwnerId)
                        {

                            txtOutput.AppendText(v.FullAddress() + " owner: " + p.FullName + "\n\n" );
                        }


                    }


                }

                var outtownQuery =
                   from prop in Sycamore.Properties
                   select prop;
                foreach (var b in outtownQuery)
                {
                    foreach (Person p in Sycamore.Residents)
                    {
                        if (DeKalb.outtowners(p) && p.Id == b.OwnerId)
                        {
                            txtOutput.AppendText(b.FullAddress() + " owner: " + p.FullName +"\n");
                        }

                    }
                }
            }
            else
            {
                txtOutput.AppendText("Please choose an option. Thank You!");
            }
            
        }
    }

}
