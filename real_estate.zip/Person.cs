﻿/**
 * @author  ibrahim khan & Michael Stockl
 * @file    Person.cs
 * @brief   Represents a person living in a community
 * @date    2020-1-31
**/
using System;
using System.Text;
using System.Collections.Generic;


namespace Khan_Stockl_Assign3
{
    class Person : IComparable
    {
        /* Limits */
        private const uint ID_MINIMUM = 1;
        private const uint ID_MAXIMUM = 99999;

        /* Private Variables */
        private readonly uint id;
        private string lastName;
        private string firstName;
        private string occupation;
        private readonly DateTime birthday;
        private List<uint> residenceIds;

        /**
         * @brief Gets a persons full name (last name, first name)
         * 
         * @returns string Person full name
         **/
        public string FullName => lastName + ", " + firstName;

        /**
         * @brief Gets persons id
         * 
         * @return uint Person id
         **/
        public uint Id => this.id;

        /**
         * @brief Sets/gets Person last name
         **/
        public string LastName
        {
            get { return this.lastName; }
            set { this.lastName = value; }
        }

        /**
         * @brief Sets/gets Person first name
         **/
        public string FirstName
        {
            get { return this.firstName; }
            set { this.firstName = value; }
        }

        /**
         * @brief Sets/gets Person occupation
         **/
        public string Occupation
        {
            get { return this.occupation; }
            set { this.occupation = value; }
        }

        /**
         * @brief Gets a persons birthday
         * 
         * @erturn DateTime persons birthday
         **/
        public DateTime Birthday => this.birthday;

        /**
         * @brief Gets a persons current age in years
         * 
         * @returns int age in years
         **/
        public int Age
        {
            get
            {
                TimeSpan age = DateTime.Now - this.Birthday;
                return (int)(age.TotalDays / 365.25);
            }
        }

        /**
         * @brief Gets a list of a persons residences 
         * 
         * @return uint[] list of residences ids 
         **/
        public uint[] ResidenceIds => this.residenceIds.ToArray();

        /**
         * @brief Grant residency to a person 
         **/
        public void addResidenceId(uint id)
        {
            this.residenceIds.Add(id);
        }

        /**
         * @brief Removes residency from a person 
         **/
        public void removeResidenceId(uint id)
        {
            this.residenceIds.Remove(id);
        }

        /**
         * @brief Constructs a Person object with default values.
        **/
        public Person() // Default
        {
            this.id = 0;
            this.lastName = "";
            this.firstName = "";
            this.occupation = "";
            this.birthday = new DateTime();
            this.residenceIds = new List<uint>();
        }

        /**
         * @brief Constructs a Person object from specified parameters
         * 
         * @param args  A string array of arguments ordered:
         *                  0: id
         *                  1: lastName
         *                  2: firstName
         *                  3: occupation
         *                  4: birthday year
         *                  5: birthday month
         *                  6: birthday day
         *                 +7: residenceIds
         *
         * @note    There may be 0 or more residenceIds
         * @warning This constructor will throw ArgumentException when unable to parse from string.
         * @warning This constructor will throw ArgumentOutOfRangeException on an invalid id or birthday.
         **/
        public Person(string[] args)
        {

            // Try parsing ID string to uint
            if (uint.TryParse(args[0], out this.id) == false) // Sets this.id on success
            {
                throw new ArgumentException("Error parsing '" + args[0] + "' into uint Person.id");
            }

            this.lastName = args[1];
            this.firstName = args[2];
            this.occupation = args[3];

            // Try parsing birthday parts (Y/M/D) to int
            int year, month, day;
            if (int.TryParse(args[4], out year) == false || int.TryParse(args[5], out month) == false || int.TryParse(args[6], out day) == false)
            {
                throw new ArgumentException("Error parsing '" + args[4] + "/" + args[5] + "/" + args[6] + "' into DateTime Person.birthday");
            }
            this.birthday = new DateTime(year, month, day);

            // Vaidate birthday range
            if (this.birthday > DateTime.Now)
            {
                throw new ArgumentOutOfRangeException("Birthday cannot be a date in the future.");
            }

            // Try parsing residence ids (rest of args array interpreted as residence ids)
            this.residenceIds = new List<uint>();
            uint tempId;
            for (uint i = 7; i < args.Length; i++)
            {
                if (uint.TryParse(args[i], out tempId) == false)
                {
                    throw new ArgumentException("Error parsing '" + args[i] + "' into uint Person.residenceIds");
                }

                this.residenceIds.Add(tempId);
            }
        }

        /**
         * @brief Constructs a Person object from specified parameters
         * 
         * @param args  A string array of arguments ordered:
         *                  0: id
         *                  1: lastName
         *                  2: firstName
         *                  3: occupation
         *                  4: birthday year
         *                  5: birthday month
         *                  6: birthday day
         *                 +7: residenceIds
         *
         * @note    There may be 0 or more residenceIds
         * @warning This constructor will throw ArgumentException when unable to parse from string.
         * @warning This constructor will throw ArgumentOutOfRangeException on an invalid id or birthday.
         **/
        public Person(string[] args, DateTime birthday)
        {

            // Try parsing ID string to uint
            if (uint.TryParse(args[0], out this.id) == false) // Sets this.id on success
            {
                throw new ArgumentException("Error parsing '" + args[0] + "' into uint Person.id");
            }

            this.lastName = args[1];
            this.firstName = args[2];
            this.occupation = args[3];

            this.birthday = birthday;

            // Vaidate birthday range
            if (this.birthday > DateTime.Now)
            {
                throw new ArgumentOutOfRangeException("Birthday cannot be a date in the future.");
            }

            // Initalize list
            this.residenceIds = new List<uint>();
        }

        /**
         * @brief CompareTo interface will sort by full name in ascending order
         * 
         * @warning This method will throw ArgumentNullException when object is null
         * @warning This method will throw ArgumentException when object is not Person
         **/
        public int CompareTo(object alpha)
        {
            if (alpha == null) throw new ArgumentNullException();

            Person rightOp = alpha as Person;

            if (rightOp != null)
            {
                return this.FullName.CompareTo(rightOp.FullName);
            }
            else
            {
                throw new ArgumentException("Person::CompareTo argument is not a Person");
            }
        }

        /**
         * @brief Gets a detail string about a person
         * 
         * @returns string person details to print
         **/
        public override string ToString()
        {
            return this.FullName + ", Age (" + this.Age + "), Occupation: " + this.Occupation;
        }

        /**
         * @brief Gets an appropriate string for display in a listbox
         * 
         * @returns string detailing the person for a listbox
         **/
        public string ToString(string type)
        {
            string returnString = "";

            switch (type)
            {
                case "ListBox":
                    returnString = this.firstName.PadRight(10) + " " + this.Age.ToString().PadRight(3) + " " + (this.Occupation.Length > 10 ? this.Occupation.Substring(0, 10) + "..." : this.Occupation);
                    break;
            }

            return returnString;
        }
    }
}
