﻿/**
 * @author  ibrahim khan & Michael Stockl
 * @file    Community.cs
 * @brief   A collection of Person and Property
 * @date    2020-1-31
**/
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Khan_Stockl_Assign3
{
    class Community : IComparable, IEnumerable
    {
        private SortedSet<Property> props;
        private SortedSet<Person> residents;
        private readonly uint id;
        private readonly string name;
        private readonly string state;
        private readonly string zip;
        private uint mayorId;

        /**
         * @brief Gets the current population count
         * 
         * @return int population count
         **/
        public int Population => this.residents.Count();

        /**
         * @brief Gets all properties of a Community
         * 
         * @return Property[] list of properties
         **/
        public Property[] Properties => this.props.ToArray<Property>();
        
        /**
         * @brief Gets all residents of a Community
         * 
         * @return Person[] list of residents
         **/
        public Person[] Residents => this.residents.ToArray<Person>();

        /**
         * @brief Gets the community id
         * 
         * @return int community id
         **/
        public uint Id => this.id;

        /**
         * @brief Gets the community name
         * 
         * @return int community name
         **/
        public string Name => this.name;

        /**
         * @brief Gets the community state
         * 
         * @return string community state 
         **/
        public string State => this.state;


        /**
         * @brief Gets the community zip
         * 
         * @return string community zip
         **/
        public string Zip => this.zip;


        /**
         * @brief Gets/Sets mayorId of Community
         **/
        public uint MayorId
        {
            get { return this.mayorId; }
            set { this.mayorId = value; }
        }

        /**
         * @brief Adds a Property to the Community
         * 
         * @param Property to add to Community
         **/
        public void AddProperty(Property p)
        {
            this.props.Add(p);
        }

        /**
         * @brief Adds a Person to the Community
         * 
         * @param Person to add to Community
         **/
        public void AddResident(Person p)
        {
            this.residents.Add(p);
        }


        /**
         * @brief Returns this Community mayor full name
         * 
         * @returns string mayors full name
         **/
        public string getMayorName()
        {
            foreach (Person p in this)
            {
                if (p.Id == this.MayorId) return p.FullName;
            }

            return "";
        }
        public bool outtowners(Person p)
        {

            //     for(int i = 0; i < this.Population;i++)
            //   {
            bool x = true;
                if(this.residents.Contains(p) == true)
                {
                x =  true;
                }
                else if(!this.residents.Contains(p) == false)
                {
                x =  false;
                }
            return x;
         //   }
        }
        /**
         * @brief Get a Property object from an address
         * 
         * @param addr Address to look up
         * 
         * @returns Property object (or null if not found)
         **/
        public Property getPropertyFromAddr(string addr)
        {
            foreach (Property p in this.Properties)
            {
                if (p.StreetAddr.ToLower() == addr.ToLower()) return p;
            }
            return null;
        }

        /**
         * @brief Get a House object from an address
         * 
         * @param addr Address to look up
         * 
         * @returns House object (or null if not found)
         **/
        public House getHouseFromAddr(string addr)
        {
            foreach (Property p in this.Properties)
            {
                if (p is House)
                {
                    if (p.StreetAddr.ToLower() == addr.ToLower()) return (House)p;
                }
            }
            return null;
        }

        /**
         * @brief Get an Apartment object from an address
         * 
         * @param addr Address to look up
         * @param unit Apartment unit
         * 
         * @returns Apartment object (or null if not found)
         **/
        public Apartment getApartmentFromAddr(string addr, string unit)
        {
            foreach (Property p in this.Properties)
            {
                if (p is Apartment)
                {
                    if (p.StreetAddr.ToLower() == addr.ToLower())
                    {
                        if (((Apartment)p).Unit.ToLower() == unit.ToLower())
                        {
                            return (Apartment)p;
                        }
                    }
                }
            }
            return null;
        }

        /**
         * @brief Get a Person object from an id
         * 
         * @param id id to look up
         * 
         * @returns Person object (or null if not found)
         **/
        public Person getPersonFromId(uint id)
        {
            foreach (Person p in this)
            {
                if (p.Id == id) return p;
            }

            return null;
        }


        /**
         * @brief Get an address from property id
         * 
         * @param id id to look up
         * 
         * @returns String of address of property (or null if not found)
         **/
        public string getAddressFromId(uint id)
        {
            foreach (Property p in this.Properties)
            {
                if (p.Id == id)
                {
                    return p.StreetAddr;
                }
            }
            return null;
        }


        /**
         * @brief Toggles a properties for sale status from id 
         * 
         * @param id Property to change for sale status
         * @returns bool? New For-Sale status (null if not found by id)
         **/
        public bool? toggleForSaleById(uint id)
        {
            foreach (Property p in this.Properties)
            {
                if (p.Id == id)
                {
                    if (p.ForSale == true)
                    {
                        p.ForSale = false;
                        return false;
                    }
                    else
                    {
                        p.ForSale = true;
                        return true;
                    }
                }
            }
            return null;
        }


        /**
         * @brief Changes a properties owner by address
         * 
         * @param addr Address of property to change
         * @param newOwner New owner id
         * 
         * @return bool true if successful (false when person / property doesn't exist)
         **/
        public bool setPropertyOwnerByAddr(string addr, uint newOwner)
        {
            // Validate owners existance in community
            bool exist = false;
            foreach (Person p in this)
            {
                if (p.Id == newOwner) exist = true;
            }

            if (exist == false) return false;

            // Search for property
            foreach (Property p in this.Properties)
            {
                if (p.StreetAddr.ToLower() == addr.ToLower())
                {
                    p.OwnerId = newOwner;
                    return true;
                }
            }

            // Property not found
            return false;
        }


        /**
         * @brief Creates a new community object with default values
         **/
        public Community()
        {
            this.props = new SortedSet<Property>();
            this.residents = new SortedSet<Person>();
            this.id = 0;
            this.name = "";
            this.state = "";
            this.zip = "";
            this.mayorId = 0;
        }

        /**
         * @brief Creates a new community object from specified parameters
         * 
         * @param personFile file from which to load the residents of this community
         * @param houseFile file from which to load house properties from
         * @param apartmentFile file from which to load apartment properties from
         * 
         * @note Temporarly hard coded to Dekalb community for assignment 
         * 
         * @warn Throws streamreader exceptions on reading errors
         **/
        public Community(string personFile, string houseFile, string apartmentFile, 
                         string businessFile, string schoolFile, uint id, string communityName, 
                         string communityState, string communityZip, uint mayorId)
        {

            this.props = new SortedSet<Property>();
            this.residents = new SortedSet<Person>();
            this.id = id;
            this.name = communityName;
            this.state = communityState;
            this.zip = communityZip;
            this.mayorId = mayorId;

            using (StreamReader inFile = new StreamReader(@personFile))
            {
                string line = inFile.ReadLine();
                while (line != null)
                {
                    this.AddResident(new Person(line.Split('\t')));
                    line = inFile.ReadLine();
                }
            }

            using (StreamReader inFile = new StreamReader(@houseFile))
            {
                string line = inFile.ReadLine();
                while (line != null)
                {
                    this.AddProperty(new House(line.Split('\t')));
                    line = inFile.ReadLine();
                }
            }

            using (StreamReader inFile = new StreamReader(@apartmentFile))
            {
                string line = inFile.ReadLine();
                while (line != null)
                {
                    this.AddProperty(new Apartment(line.Split('\t')));
                    line = inFile.ReadLine();
                }
            }

            using (StreamReader inFile = new StreamReader(@businessFile))
            {
                string line = inFile.ReadLine();
                while (line != null)
                {
                    this.AddProperty(new Business(line.Split('\t')));
                    line = inFile.ReadLine();
                }
            }

            using (StreamReader inFile = new StreamReader(@schoolFile))
            {
                string line = inFile.ReadLine();
                while (line != null)
                {
                    this.AddProperty(new School(line.Split('\t')));
                    line = inFile.ReadLine();
                }
            }
        }

        /**
         * @brief CompareTo interface will sort by full name in ascending order
         * 
         * @warning This method will throw ArgumentNullException when object is null
         * @warning This method will throw ArgumentException when object is not Person
         **/
        public int CompareTo(object alpha)
        {
            if (alpha == null) throw new ArgumentNullException();

            Community rightOp = alpha as Community;

            if (rightOp != null)
            {
                return this.Name.CompareTo(rightOp.Name);
            }
            else
            {
                throw new ArgumentException("Community::CompareTo argument is not a Community");
            }
        }

        /**
         * @brief Returns a detailed string about the community
         * 
         * @return string detailed string about the community
         **/
        public override string ToString()
        {
            return "<" + this.Id + "> " + this.Name + ". Population (" + this.Population + "). Mayor: " + this.getMayorName();
        }

        /***********************************************************************************************************************************************************
         * IEnumerable / IEnumerator Implementation Below
         ***********************************************************************************************************************************************************/
        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public IEnumerator GetEnumerator()
        {
            return new CommunityEnum(this.Residents);
        }
    }

    class CommunityEnum : IEnumerator
    {
        private Person[] residents;
        private int position = -1;

        public CommunityEnum(Person[] residents)
        {
            this.residents = residents;
        }

        public bool MoveNext()
        {
            position++;
            return (position < this.residents.Length);
        }

        public void Reset()
        {
            position = -1;
        }

        object IEnumerator.Current
        {
            get { return Current; }
        }

        public Person Current
        {
            get
            {
                try
                {
                    return residents[position];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }
}
