﻿/**
 * @author  ibrahim khan & Michael Stockl
 * @file    Residential.cs
 * @brief   Represents Property:Residential object 
 * @date    2020-1-31
**/
using System;

namespace Khan_Stockl_Assign3
{
    class Residential : Property
    {
        /* Private Variables */
        private uint bedrooms;
        private uint baths;
        private uint sqft;

        /**
        * @brief Gets the amount of bedrooms
        * 
        * @return uint Bedroom count
        **/
        public uint Bedrooms
        {
            get { return this.bedrooms; }
            set { this.bedrooms = value; }
        }

        /**
        * @brief Gets the amount of baths
        * 
        * @return uint Bath count
        **/
        public uint Baths
        {
            get { return this.baths; }
            set { this.baths = value; }
        }

        /**
        * @brief Gets the square footage
        * 
        * @return uint square footage 
        **/
        public uint Sqft
        {
            get { return this.sqft; }
            set { this.sqft = value; }
        }

        /**
         * @brief Creates a Residential object with default values
         **/
        public Residential() : base()
        {
            this.bedrooms = 0;
            this.baths = 0;
            this.sqft = 0;
        }

        /**
         * @brief Creates a Residential object with specified values
         * 
         * @param args A string array of arguments ordered:
         *                  0: id
         *                  1: ownerId
         *                  2: x
         *                  3: y
         *                  4: streetAddr
         *                  5: city
         *                  6: state
         *                  7: zip
         *                  8: forSale
         *                  9: bedrooms
         *                 10: baths
         *                 11: sqft
         *                
         * @note arg index 0-8 is used in base class construction
         **/
        public Residential(string[] args) : base(args)
        {
            // Try parsing bedrooms string to uint
            if (uint.TryParse(args[9], out this.bedrooms) == false)
            {
                throw new ArgumentException("Error parsing '" + args[9] + "' into uint Property::Residential.bedroom");
            }

            // Try parsing baths string to uint
            if (uint.TryParse(args[10], out this.baths) == false)
            {
                throw new ArgumentException("Error parsing '" + args[10] + "' into uint Property::Residential.baths");
            }

            // Try parsing sqft to uint
            if (uint.TryParse(args[11], out this.sqft) == false)
            {
                throw new ArgumentException("Error parsing '" + args[11] + "' into uint Property::Residential.baths");
            }
        }

    }
}
