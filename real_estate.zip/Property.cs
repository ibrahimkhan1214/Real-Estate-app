﻿/**
 * @author  ibrahim khan & Michael Stockl
 * @file    Property.cs
 * @brief   Represents Property beloging to a community
 * @date    2020-1-31
**/
using System;
using System.Text;


namespace Khan_Stockl_Assign3
{
    class Property : IComparable
    {
        /* Private Variables */
        private readonly uint id;
        private uint ownerId;
        private readonly uint x;
        private readonly uint y;
        private string streetAddr;
        private string city;
        private string state;
        private string zip;
        private bool forSale;
        private uint salePrice;

        /**
         * @brief Returns Property readonly Id
         * 
         * @return uint property id 
         **/
        public uint Id => this.id;

        /**
         * @brief Sets/gets Property ownerId
         **/
        public uint OwnerId
        {
            get { return this.ownerId; }
            set { this.ownerId = value; }
        }

        /**
         * @brief Returns Property x position
         * 
         * @return uint x position
         **/
        public uint X => this.x;

        /**
         * @brief Returns Property y position
         * 
         * @return uint y position
         **/
        public uint Y => this.y;

        /**
         * @brief Sets/gets Property street address
         **/
        public string StreetAddr
        {
            get { return this.streetAddr; }
            set { this.streetAddr = value; }
        }

        /**
         * @brief Sets/gets Property city
         **/
        public string City
        {
            get { return this.city; }
            set { this.city = value; }
        }

        /**
         * @brief Sets/gets Property state
         **/
        public string State
        {
            get { return this.state; }
            set { this.state = value; }
        }

        /**
         * @brief Sets/gets Property zip
         **/
        public string Zip
        {
            get { return this.zip; }
            set { this.zip = value; }
        }

        /**
         * @brief Sets/gets Property for sale flag
         **/
        public bool ForSale
        {
            get { return this.forSale; }
            set { this.forSale = value; }
        }

        /**
         * @brief Sets/gets Property for sale price
         **/
         public uint SalePrice
        {
            get { return this.salePrice; }
            set { this.salePrice = value; }
        }


        /**
         * @brief Virtual function to be overriden by House/Apartment
         * 
         * @returns string Street Address
         **/
        public virtual string FullAddress()
        {
            return this.StreetAddr;
        }

        /**
         * @brief Constructs a Property object with default values
         **/
        public double distanceCalc(double x1, double x2, double y1, double y2)
        {
            double dis = Math.Sqrt(Math.Pow((x2 - x1), 2) + Math.Pow((y2 - y1), 2));
            return dis;
        }
        public Property()
        {
            this.id = 0;
            this.ownerId = 0;
            this.x = 0;
            this.y = 0;
            this.streetAddr = "";
            this.city = "";
            this.state = "";
            this.zip = "";
            this.forSale = true;
            this.salePrice = 0;
        }

        /**
         * @brief Constructs a Property object with specified parameters
         * 
         * @param args A string array of arguments ordered:
         *                  0: id
         *                  1: ownerId
         *                  2: x
         *                  3: y
         *                  4: streetAddr
         *                  5: city
         *                  6: state
         *                  7: zip
         *                  8: forSale
         * @warning This constructor will throw ArgumentException when unable to parse from string.
         **/
        public Property(params string[] args)
        {
            // Try parsing id string to uint
            if (uint.TryParse(args[0], out this.id) == false)
            {
                throw new ArgumentException("Error parsing '" + args[0] + "' into uint Property.id");
            }

            // Try parsing ownerid to uint
            if (uint.TryParse(args[1], out this.ownerId) == false)
            {
                throw new ArgumentException("Error parsing '" + args[1] + "' into uint Property.ownerId");
            }

            //  Try parsing x into uint
            if (uint.TryParse(args[2], out this.x) == false)
            {
                throw new ArgumentException("Error parsing '" + args[2] + "' into uint Property.x");
            }

            // Try parsing y into uint
            if (uint.TryParse(args[3], out this.y) == false)
            {
                throw new ArgumentException("Error parsing '" + args[3] + "' into uint Property.x");
            }

            this.streetAddr = args[4];
            this.city = args[5];
            this.state = args[6];
            this.zip = args[7];

            // Try parsing forsale into bool
            if (args[8][0] == 'T')
            {
                this.forSale = true;
                if ( uint.TryParse(args[8].Substring(2, args[8].Length - 2), out this.salePrice) == false )
                {
                    throw new ArgumentException("Error parsing '" + args[8].Substring(2, args[8].Length - 2) + "' into Property.salePrice");
                }
            }
            else if (args[8][0] == 'F')
            {
                this.forSale = false;
            }
            else
            {
                throw new ArgumentException("Error parsing '" + args[8] + "' into bool Property.forSale");
            }
        }
        /**
         * @brief CompareTo interface will sort in order: (State, City, Street Address (name first, then number))
         * 
         * @warning This method will throw ArgumentNullException when object is null
         * @warning This method will throw ArgumentException when object is not Property
         **/
        public int CompareTo(object alpha)
        {
            if (alpha == null) throw new ArgumentNullException();

            Property rightOp = alpha as Property;

            if (alpha != null)
            {
                int compVal;
                string thisStreetComp;
                string rightOpStreetComp;


                // Compare state 
                compVal = this.State.CompareTo(rightOp.State);
                if (compVal != 0) return compVal;

                // Compare city
                compVal = this.City.CompareTo(rightOp.City);
                if (compVal != 0) return compVal;

                // Compare street name
                thisStreetComp = getStreetName(this.StreetAddr);
                rightOpStreetComp = getStreetName(rightOp.StreetAddr);
                compVal = thisStreetComp.CompareTo(rightOpStreetComp);
                if (compVal != 0) return compVal;

                // Compare street number
                thisStreetComp = getStreetNum(this.StreetAddr);
                rightOpStreetComp = getStreetNum(rightOp.StreetAddr);
                compVal = thisStreetComp.CompareTo(rightOpStreetComp);
                if (compVal != 0) return compVal;

                // Compare apt# if applicable
                if (this is Apartment && rightOp is Apartment)
                {
                    Apartment rightOpApt = rightOp as Apartment;
                    Apartment thisApt = this as Apartment;
                    compVal = thisApt.Unit.CompareTo(rightOpApt.Unit);
                    if (compVal != 0) return compVal;
                }

                // If we're here, they are equal
                return 0;
            }
            else
            {
                throw new ArgumentException("Property::CompareTo argument is not a Property");
            }
        }

        /**
         * @brief Extracts street number from full address
         * 
         * @param fullAddr Address to split
         * @returns string street number
         **/
        private string getStreetNum(string fullAddr)
        {
            return fullAddr.Split()[0];
        }

        /**
         * @brief Extracts street name from full address
         * 
         * @param fullAddr Address to split
         * @returns string street name
         **/
        private string getStreetName(string fullAddr)
        {
            string[] split = fullAddr.Split();
            StringBuilder streetname = new StringBuilder();

            for (int i = 1; i < split.Length - 1; i++)
            {
                streetname.Append(split[i]);
            }

            return streetname.ToString();
        }

        /**
         * @brief Generates a detailed string about a property
         * 
         * @return string Detailed string about property
         **/
        public string DetailString(Community c)
        {
            StringBuilder detail = new StringBuilder();

            detail.Append("Property Address: " + this.StreetAddr + " / " + this.City + " / " + this.State + " / " + this.Zip + "\n");
            detail.Append("\tOwned by " + c.getPersonFromId(this.OwnerId).ToString() + "\n");

            string forSaleString;
            if (this.ForSale == true)
            {
                forSaleString = "(FOR SALE)";
            }
            else
            {
                forSaleString = "(NOT for sale)";
            }

            Residential res = this as Residential;
            detail.Append("\t" + forSaleString + " " + res.Bedrooms + " bedrooms \\ " + res.Baths + " baths \\ " + res.Sqft + " sq.ft.");

            if (this is House)
            {
                detail.Append("\n\t");
                House house = this as House;
                switch (house.AttachedGarage)
                {
                    // No garage
                    case null:
                        detail.Append("... with no garage : ");
                        break;

                    // Garage and attached
                    case true:
                        detail.Append("... with an attached garage : ");
                        break;

                    // Garage and not attached
                    case false:
                        detail.Append("... with a detached garage : ");
                        break;
                }

                if (house.Floors == 1)
                {
                    detail.Append(house.Floors + " floor." + "\n");
                }
                else
                {
                    detail.Append(house.Floors + " floors." + "\n");
                }
            }
            else if (this is Apartment)
            {
                Apartment apt = this as Apartment;
                detail.Append(" Apt.# " + apt.Unit + "\n");
            }

            return detail.ToString();
        }
    }
}
