﻿/**
 * @author  ibrahim khan & Michael Stockl
 * @file    Apartment.cs
 * @brief   Represents Property:Residential:Apartment object
 * @date    2020-1-31
**/
namespace Khan_Stockl_Assign3
{
    class Apartment : Residential
    {
        /* Private Variables */
        private string unit;

        /**
         * @brief Returns Apartment unit
         * 
         * @return string Unit 
         */
        public string Unit
        {
            get { return this.unit; }
            set { this.unit = value; }
        }

        /**
         * @brief Gets full address of apartment
         * 
         * @returns string full address of apartment
         **/
        public override string FullAddress()
        {
            return this.StreetAddr + " Apt.# " + this.Unit + " " + this.City + ", " + this.State + ", " + this.Zip;
        }

        /**
         * @brief Creates an Apartment object with default values
         **/
        public Apartment() : base()
        {
            this.unit = "";
        }

        /**
         * @brief Constructs an Apartment object with specified values
         * 
         * @param args A string array of arguments ordered:
         *                  0: id
         *                  1: ownerId
         *                  2: x
         *                  3: y
         *                  4: streetAddr
         *                  5: city
         *                  6: state
         *                  7: zip
         *                  8: forSale
         *                  9: bedrooms
         *                 10: baths
         *                 11: sqft
         *                 12: unit
         *                 
         * @note arg index 0-11 is used in base class construction
         **/
        public Apartment(string[] args) : base(args)
        {
            this.unit = args[12];
        }
    }
}
