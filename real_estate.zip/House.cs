﻿/**
 * @author  ibrahim khan & Michael Stockl
 * @file    House.cs
 * @brief   Represents Property:Residential:House object
 * @date    2020-1-31
**/
using System;

namespace Khan_Stockl_Assign3
{
    class House : Residential
    {
        /* Private Variables */
        private bool garage;
        private bool? attachedGarage;  // Null when garage==false;
        private uint floors;

        /**
        * @breif Checks if the house has a garage
        * 
        * @returns bool garage status
        **/
        public bool Garage
        {
            get { return this.garage; }
            set { this.garage = value; }
        }

        /**
        * @breif Checks if the house has an attached garage
        * 
        * @returns bool attached garage status (null = no garage)
        **/
        public bool? AttachedGarage
        {
            get { return this.attachedGarage; }
            set { this.attachedGarage = value; }
        }

        /**
        * @brief Gets/sets floor count of house
        **/
        public uint Floors
        {
            get { return this.floors; }
            set { this.floors = value; }
        }


        /**
         * @brief Gets full address of house
         * 
         * @returns string full address of house
         **/
        public override string FullAddress()
        {
            return this.StreetAddr + " " + this.City + ", " + this.State + ", " + this.Zip;
        }


        /**
         * @brief Constructs a House object with default values
         **/
        public House() : base()
        {
            this.garage = false;
            this.attachedGarage = null;
            this.floors = 0;
        }

        /**
         * @brief Constructs a House object with specified values
         * 
         * @param args A string array of arguments ordered:
         *                  0: id
         *                  1: ownerId
         *                  2: x
         *                  3: y
         *                  4: streetAddr
         *                  5: city
         *                  6: state
         *                  7: zip
         *                  8: forSale
         *                  9: bedrooms
         *                 10: baths
         *                 11: sqft
         *                 12: garage
         *                 13: attachedGarage
         *                 14: floors
         *                 
         * @note arg index 0-11 is used in base class construction
         **/
        public House(string[] args) : base(args)
        {
            // Try parsing garage
            if (args[12] == "T")
            {
                this.garage = true;

                // Try parsing attached garage
                if (args[13] == "T")
                {
                    this.attachedGarage = true;
                }
                else if (args[13] == "F")
                {
                    this.attachedGarage = false;
                }
                else
                {
                    throw new ArgumentException("Error parsing '" + args[13] + "' into bool Property::Residential::House.attachedGarage");
                }
            }
            else if (args[12] == "F")
            {
                this.garage = false;
                this.attachedGarage = null;
            }
            else
            {
                throw new ArgumentException("Error parsing '" + args[12] + "' into bool Property::Residential::House.garage");
            }

            // Try parsing floor count
            if (uint.TryParse(args[14], out this.floors) == false)
            {
                throw new ArgumentException("Error parsing '" + args[14] + "' into uint Property::Residential::House.floors");
            }
        }

    }
}
