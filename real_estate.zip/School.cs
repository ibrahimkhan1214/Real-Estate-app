﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Khan_Stockl_Assign3
{
    class School : Property
    {
        public enum SchoolType { Elementary, HighSchool, CommunityCollege, University };

        /* Private Data */
        private string name;
        private readonly SchoolType type;
        private readonly string yearEstablished;
        private uint enrolled;

        public string Name { get => name; set => name = value; }

        internal SchoolType Type => type;

        public string YearEstablished => yearEstablished;

        public uint Enrolled { get => enrolled; set => enrolled = value; }


        /**
         * @brief Creates a new School object with default parameters
         **/
        public School() : base()
        {
            this.Name = "";
            this.type = SchoolType.Elementary;
            this.yearEstablished = "";
            this.Enrolled = 0;
        }


       /**
        * @brief Creates a School object with specified values
        * 
        * @param args A string array of arguments ordered:
        *                  0: id
        *                  1: ownerId
        *                  2: x
        *                  3: y
        *                  4: streetAddr
        *                  5: city
        *                  6: state
        *                  7: zip
        *                  8: forSale
        *                  9: schoolName
        *                 10: yearEstablished
        *                 11: enrollment       
        * @note arg index 0-8 is used in base class construction
        **/
        public School( string[] args ) : base(args)
        {
            this.Name = args[9];
            this.yearEstablished = args[10];

            if (uint.TryParse(args[11], out this.enrolled) == false)
            {
                throw new ArgumentException("Error parsing '" + args[11] + "' into uint School.enrolled");
            }

            if (this.Name.ToLower().Contains("elementary"))
            {
                this.type = SchoolType.Elementary;
            }
            else if (this.Name.ToLower().Contains("high"))
            {
                this.type = SchoolType.HighSchool;
            }
            else if (this.Name.ToLower().Contains("community"))
            {
                this.type = SchoolType.CommunityCollege;
            }
            else if (this.Name.ToLower().Contains("university"))
            {
                this.type = SchoolType.University;
            }
            else
            {
                throw new ArgumentException("Unable to determine School.SchoolType");
            }
        }





    }
}
